<?php

namespace App\Services;

use App\Models\Invoice;
use App\Models\Payment;
use App\Models\PaymentVoid;
use App\Models\Customer;
use App\Models\AdvanceTransaction;
use App\Models\Income;
use App\Models\IncomeCategory;
use App\Models\Setting;
use App\Services\SmsService;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class BillingService
{
    /**
     * Collect payment using FIFO logic.
     * Regardless of which invoice is selected, the oldest unpaid invoice is paid first.
     * Any excess amount is added to the customer's advance balance.
     * After payment, checks if MikroTik auto restore is needed.
     */
    public function collectPayment(Customer $customer, array $data): array
    {
        return DB::transaction(function () use ($customer, $data) {

            $totalPaid    = floatval($data['amount']);
            $remaining    = $totalPaid;
            $paidInvoices = [];

            // FIFO — oldest unpaid invoice first
            $unpaidInvoices = Invoice::where('customer_id', $customer->id)
                ->whereIn('status', ['unpaid', 'partial', 'overdue'])
                ->orderBy('month', 'asc')
                ->get();

            foreach ($unpaidInvoices as $invoice) {
                if ($remaining <= 0) break;

                $due = floatval($invoice->due_amount);

                if ($remaining >= $due) {
                    // Fully pay this invoice
                    $payAmount = $due;
                    $remaining -= $due;

                    $payment = Payment::create([
                        'invoice_id'            => $invoice->id,
                        'customer_id'           => $customer->id,
                        'amount'                => $payAmount,
                        'method'                => $data['method'],
                        'transaction_id'        => $data['transaction_id'] ?? null,
                        'remarks'               => $data['remarks'] ?? null,
                        'received_by'           => $data['received_by'] ?? null,
                        'receive_from'          => $data['receive_from'] ?? null,
                        'send_sms'              => $data['send_sms'] ?? false,
                        'set_next_billing_date' => $data['set_next_billing_date'] ?? false,
                        'payment_date'          => $data['payment_date'] ?? now()->toDateString(),
                        'status'                => 'active',
                        'paid_at'               => now(),
                    ]);

                    $this->createIncomeForPayment($payment, $invoice);

                    $invoice->update(['due_amount' => 0, 'status' => 'paid']);
                    $paidInvoices[] = $invoice->invoice_no;

                } else {
                    // Partial payment
                    $payAmount = $remaining;
                    $remaining = 0;

                    $payment = Payment::create([
                        'invoice_id'            => $invoice->id,
                        'customer_id'           => $customer->id,
                        'amount'                => $payAmount,
                        'method'                => $data['method'],
                        'transaction_id'        => $data['transaction_id'] ?? null,
                        'remarks'               => $data['remarks'] ?? null,
                        'received_by'           => $data['received_by'] ?? null,
                        'receive_from'          => $data['receive_from'] ?? null,
                        'send_sms'              => $data['send_sms'] ?? false,
                        'set_next_billing_date' => $data['set_next_billing_date'] ?? false,
                        'payment_date'          => $data['payment_date'] ?? now()->toDateString(),
                        'status'                => 'active',
                        'paid_at'               => now(),
                    ]);

                    $this->createIncomeForPayment($payment, $invoice);

                    $invoice->update([
                        'due_amount' => $due - $payAmount,
                        'status'     => 'partial',
                    ]);

                    $paidInvoices[] = $invoice->invoice_no . ' (partial)';
                }
            }

            // Add any excess amount to advance balance
            if ($remaining > 0) {
                $customer->increment('advance_balance', $remaining);
                AdvanceTransaction::create([
                    'customer_id' => $customer->id,
                    'type'        => 'credit',
                    'amount'      => $remaining,
                    'description' => 'Advance from overpayment',
                    'created_by'  => auth()->id(),
                ]);
            }

            // Auto restore MikroTik if setting enabled and all dues cleared
            $this->checkAndRestoreMikrotik($customer);

            // Send payment confirmation SMS — requires BOTH:
            //  1. the global "Payment Confirmation" notification toggle (Settings →
            //     Notification → payment_confirm_sms) to be enabled, AND
            //  2. the "send_sms" checkbox on this specific payment form to be checked.
            // Previously the global toggle wasn't checked at all, so disabling it in
            // Settings had no effect — SMS still went out as long as the per-payment
            // checkbox was ticked.
            $paymentConfirmSmsEnabled = Setting::get('payment_confirm_sms', '1') == '1';

            if ($paymentConfirmSmsEnabled && !empty($data['send_sms'])) {
                try {
                    (new SmsService(macResellerId: $customer->mac_reseller_id))->sendPaymentConfirm(
                        $customer->phone,
                        $customer->name,
                        $totalPaid,
                        $data['method']
                    );
                } catch (\Exception $e) {
                    \Log::error('Payment confirmation SMS failed: ' . $e->getMessage());
                }
            }

            return [
                'paid_invoices' => $paidInvoices,
                'advance_added' => $remaining > 0 ? $remaining : 0,
                'total_paid'    => $totalPaid,
            ];
        });
    }

    /**
     * Auto-deduct from advance balance when a new invoice is generated.
     */
    public function applyAdvanceToInvoice(Invoice $invoice): void
    {
        DB::transaction(function () use ($invoice) {

            $customer = Customer::lockForUpdate()->find($invoice->customer_id);
            $invoice  = Invoice::lockForUpdate()->find($invoice->id);

            $due     = floatval($invoice->due_amount);
            $advance = floatval($customer->advance_balance);

            if ($advance <= 0) return;

            if ($advance >= $due) {
                $deduct = $due;
                Payment::create([
                    'invoice_id'   => $invoice->id,
                    'customer_id'  => $customer->id,
                    'amount'       => $deduct,
                    'method'       => 'advance',
                    'remarks'      => 'Auto-deducted from advance balance',
                    'payment_date' => now()->toDateString(),
                    'status'       => 'active',
                    'paid_at'      => now(),
                ]);
                $invoice->update(['due_amount' => 0, 'status' => 'paid']);
                $customer->decrement('advance_balance', $deduct);

            } else {
                $deduct = $advance;
                Payment::create([
                    'invoice_id'   => $invoice->id,
                    'customer_id'  => $customer->id,
                    'amount'       => $deduct,
                    'method'       => 'advance',
                    'remarks'      => 'Auto-deducted from advance balance',
                    'payment_date' => now()->toDateString(),
                    'status'       => 'active',
                    'paid_at'      => now(),
                ]);
                $invoice->update([
                    'due_amount' => $due - $deduct,
                    'status'     => 'partial',
                ]);
                $customer->decrement('advance_balance', $deduct);
            }

            AdvanceTransaction::create([
                'customer_id' => $customer->id,
                'type'        => 'debit',
                'amount'      => $deduct,
                'description' => 'Auto-deducted for invoice ' . $invoice->invoice_no,
                'invoice_id'  => $invoice->id,
            ]);

            // Auto restore MikroTik if all dues cleared
            $this->checkAndRestoreMikrotik($customer);
        });
    }

    /**
     * Void a payment.
     * Only marks the payment as void and recalculates invoice status.
     * Does NOT refund to advance balance.
     */
    public function voidPayment(Payment $payment, string $reason): void
    {
        DB::transaction(function () use ($payment, $reason) {

            $payment->update(['status' => 'void']);

            PaymentVoid::create([
                'payment_id' => $payment->id,
                'voided_by'  => auth()->id(),
                'amount'     => $payment->amount,
                'reason'     => $reason,
                'voided_at'  => now(),
            ]);

            // Income void — source_type=monthly_bill, source_id=payment.id
            $income = Income::where('source_type', Income::SOURCE_MONTHLY_BILL)
                ->where('source_id', $payment->id)
                ->first();

            if ($income) {
                $income->update([
                    'status'      => 'void',
                    'void_reason' => $reason,
                    'void_date'   => now(),
                    'void_by'     => auth()->id(),
                ]);
            }

            $invoice   = $payment->invoice;
            $totalPaid = $invoice->payments()->active()->sum('amount');
            $due       = $invoice->amount - $invoice->discount - $totalPaid;

            if ($due <= 0) {
                $status = 'paid';
                $due    = 0;
            } elseif ($totalPaid > 0) {
                $status = 'partial';
            } else {
                $status = 'unpaid';
            }

            $invoice->update(['due_amount' => $due, 'status' => $status]);
        });
    }

    /**
     * Manually add advance balance for a customer.
     */
    public function addAdvance(Customer $customer, array $data): Payment
    {
        return DB::transaction(function () use ($customer, $data) {

            $payment = Payment::create([
                'invoice_id'     => null,
                'customer_id'    => $customer->id,
                'amount'         => $data['amount'],
                'method'         => $data['method'],
                'transaction_id' => $data['transaction_id'] ?? null,
                'remarks'        => $data['remarks'] ?? 'Manual advance',
                'received_by'    => $data['received_by'] ?? null,
                'payment_date'   => $data['payment_date'] ?? now()->toDateString(),
                'status'         => 'active',
                'paid_at'        => now(),
            ]);

            $customer->increment('advance_balance', $data['amount']);

            AdvanceTransaction::create([
                'customer_id' => $customer->id,
                'type'        => 'credit',
                'amount'      => $data['amount'],
                'description' => 'Manual advance payment',
                'payment_id'  => $payment->id,
                'created_by'  => auth()->id(),
            ]);

            return $payment;
        });
    }

    /**
     * Generate invoice for Date to Date billing.
     * Period: connection_date → connection_date + 29 days (30 days total)
     */
    public function generateDateToDateInvoice(Customer $customer): ?Invoice
    {
        $connectionDate = $customer->connection_date;

        if (!$connectionDate) return null;

        // Find last invoice to determine next period start
        $lastInvoice = Invoice::where('customer_id', $customer->id)
            ->where('billing_type', 'date_to_date')
            ->latest('period_start')
            ->first();

        if ($lastInvoice) {
            $periodStart = Carbon::parse($lastInvoice->period_end)->addDay();
        } else {
            $periodStart = Carbon::parse($connectionDate);
        }

        $periodEnd = $periodStart->copy()->addDays(29); // 30 days total

        // The period must have actually ended before we bill for it — otherwise a
        // customer's very first invoice (or any subsequent one) gets generated the
        // moment the command runs, regardless of how many days have actually passed
        // since connection/last period. This was missing entirely before.
        if (now()->lt($periodEnd)) {
            return null;
        }

        // Check if already generated for this period — filtered by billing_type too,
        // so this can't accidentally match a differently-typed invoice that happens
        // to share the same period_start value.
        $exists = Invoice::where('customer_id', $customer->id)
            ->where('billing_type', 'date_to_date')
            ->where('period_start', $periodStart->toDateString())
            ->exists();

        if ($exists) return null;

        // Reseller customers have no package_id (they use mac_reseller_tariff_package_id
        // instead), so $customer->package is always null for them — falling back to
        // their own monthly_bill_amount (set at creation/import time) instead of
        // silently billing them ৳0. Admin customers are completely unaffected.
        $amount = $customer->mac_reseller_id
            ? (float) ($customer->monthly_bill_amount ?? 0)
            : (float) ($customer->package->price ?? 0);

        // Same reasoning for the due-days setting — a reseller's own Settings page
        // (Billing → Invoice Due After) should govern their own customers' due date,
        // not the ISP Admin's global setting.
        $dueDays = $customer->mac_reseller_id
            ? intval(\App\Models\ResellerSetting::get($customer->mac_reseller_id, 'invoice_due_days', 7))
            : intval(Setting::get('invoice_due_days', 7));
        $dueDate = $periodStart->copy()->addDays($dueDays);

        try {
            $invoice = Invoice::create([
                'invoice_no'   => Invoice::generateNumber(),
                'customer_id'  => $customer->id,
                'package_id'   => $customer->package_id,
                'month'        => $periodStart->format('Y-m'),
                'period_start' => $periodStart->toDateString(),
                'period_end'   => $periodEnd->toDateString(),
                'billing_type' => 'date_to_date',
                'amount'       => $amount,
                'due_amount'   => $amount,
                'due_date'     => $dueDate->toDateString(),
                'status'       => 'unpaid',
            ]);
        } catch (\Illuminate\Database\QueryException $e) {
            // Unique constraint (invoices_customer_period_type_unique) caught a race
            // condition — another process already created this exact invoice between
            // our exists() check above and this insert. Treat as "already generated",
            // not an error.
            if ($e->getCode() === '23000') {
                \Log::info("Duplicate date-to-date invoice prevented by DB constraint for customer #{$customer->id}, period {$periodStart->toDateString()}.");
                return null;
            }
            throw $e;
        }

        // Auto-deduct advance if available
        if ($customer->advance_balance > 0) {
            $this->applyAdvanceToInvoice($invoice);
        }

        // Send "Invoice Generated" SMS if the global notification toggle is on
        // (Settings → Notification → invoice_generated_sms) and the customer has a phone.
        if (Setting::get('invoice_generated_sms', '1') == '1' && $customer->phone) {
            try {
                      
           $totalDue = Invoice::where('customer_id', $customer->id)
            ->whereIn('status', ['unpaid', 'partial', 'overdue'])
            ->sum('due_amount');
            
                (new SmsService(macResellerId: $customer->mac_reseller_id))->sendInvoiceGenerated(
                    $customer->phone,
                    $customer->name,
                   // floatval($invoice->due_amount),
                    floatval($totalDue),
                    $invoice->month
                );
            } catch (\Exception $e) {
                \Log::error('Invoice generated SMS failed: ' . $e->getMessage());
            }
        }

        return $invoice;
    }

    /**
     * Check overdue invoices based on grace period setting.
     * Run via scheduler.
     */
    public function markOverdueInvoices(): int
    {
        $gracePeriod = intval(Setting::get('grace_period_days', 3));
        $cutoffDate  = now()->subDays($gracePeriod)->toDateString();

        $count = Invoice::whereIn('status', ['unpaid', 'partial'])
            ->whereNotNull('due_date')
            ->whereDate('due_date', '<', $cutoffDate)
            ->update(['status' => 'overdue']);

        return $count;
    }

    /**
     * Apply late fee to overdue invoices.
     * Run via scheduler.
     */
    public function applyLateFees(): int
    {
        $lateFeeAmount = floatval(Setting::get('late_fee_amount', 0));
        $lateFeeAfter  = intval(Setting::get('late_fee_after_days', 7));

        if ($lateFeeAmount <= 0) return 0;

        $cutoffDate = now()->subDays($lateFeeAfter)->toDateString();
        $count      = 0;

        $overdueInvoices = Invoice::where('status', 'overdue')
            ->whereDate('due_date', '<', $cutoffDate)
            ->whereNull('late_fee_applied_at')
            ->get();

        foreach ($overdueInvoices as $invoice) {
            $invoice->increment('due_amount', $lateFeeAmount);
            $invoice->increment('amount', $lateFeeAmount);
            $invoice->update(['late_fee_applied_at' => now()]);
            $count++;
        }

        return $count;
    }

    /**
     * Create Income record for a monthly bill payment.
     */
    private function createIncomeForPayment(Payment $payment, Invoice $invoice): void
    {
        $category = IncomeCategory::where('slug', 'monthly-bill')
            ->orWhere('name', 'Monthly Bill')
            ->first();

        if (! $category) return;

        $customer = $invoice->customer;

        Income::create([
            'income_no'         => Income::generateNumber(),
            'category_id'       => $category->id,
            'amount'            => $payment->amount,
            'income_date'       => $payment->payment_date,
            'payment_method'    => $payment->method,
            'transaction_id'    => $payment->transaction_id,
            'customer_id'       => $customer->id,
            'payer'             => $customer->name,
            'reference_no'      => $payment->id,
            'description'       => "Invoice: {$invoice->invoice_no} | Customer: {$customer->name}",
            'source_type'       => Income::SOURCE_MONTHLY_BILL,
            'source_id'         => $payment->id,
            'source_invoice_id' => $invoice->id,
            'status'            => 'active',
            'created_by'        => auth()->id(),
        ]);
    }

    /**
     * Check if MikroTik auto restore is needed after payment.
     */
    public function checkAndRestoreMikrotik(Customer $customer): void
    {
        // Check if auto restore is enabled in settings
        $autoRestore = Setting::get('mikrotik_auto_restore_on_payment', false);

        if (!$autoRestore) return;

        // Check if all invoices are paid
        $hasDue = $customer->invoices()
            ->whereIn('status', ['unpaid', 'partial', 'overdue'])
            ->exists();

        if (!$hasDue && $customer->router_id) {
            // All dues cleared — restore MikroTik
            try {
                app(\App\Http\Controllers\MikrotikController::class)
                    ->restoreCustomerById($customer->id);
            } catch (\Exception $e) {
                \Log::error('MikroTik restore failed for customer ' . $customer->id . ': ' . $e->getMessage());
            }
        }
    }

    /**
     * Get stats data for invoice list page cards.
     */
    public function getInvoiceStats(): array
    {
        $thisMonth = now()->format('Y-m');
        $lastMonth = now()->subMonth()->format('Y-m');

        // ── Admin's stat cards should reflect Admin's own customers only —
        //    NOT customers added by a MAC Reseller (they get their own stats
        //    on the reseller portal's Billing page). ──
        $adminOnly = fn($q) => $q->whereHas('customer', fn($c) => $c->whereNull('mac_reseller_id'));

        $paidThis   = Invoice::where('month', $thisMonth)->where('status', 'paid')->tap($adminOnly)->count();
        $paidLast   = Invoice::where('month', $lastMonth)->where('status', 'paid')->tap($adminOnly)->count();

        $unpaidThis = Invoice::where('month', $thisMonth)->whereIn('status', ['unpaid', 'partial', 'overdue'])->tap($adminOnly)->count();
        $unpaidLast = Invoice::where('month', $lastMonth)->whereIn('status', ['unpaid', 'partial', 'overdue'])->tap($adminOnly)->count();

        $receivedThis = Payment::active()->thisMonth()->whereHas('customer', fn($c) => $c->whereNull('mac_reseller_id'))->sum('amount');
        $receivedLast = Payment::active()
            ->whereMonth('payment_date', now()->subMonth()->month)
            ->whereYear('payment_date', now()->subMonth()->year)
            ->whereHas('customer', fn($c) => $c->whereNull('mac_reseller_id'))
            ->sum('amount');

        $totalDue = Invoice::whereIn('status', ['unpaid', 'partial', 'overdue'])->tap($adminOnly)->sum('due_amount');

        $generatedThis = Invoice::where('month', $thisMonth)->tap($adminOnly)->count();
        $generatedLast = Invoice::where('month', $lastMonth)->tap($adminOnly)->count();

        $advanceTotal    = Customer::whereNull('mac_reseller_id')->sum('advance_balance');
        $monthlyBillThis = Invoice::where('month', $thisMonth)->tap($adminOnly)->sum('amount');
        $monthlyBillLast = Invoice::where('month', $lastMonth)->tap($adminOnly)->sum('amount');

        $totalClients       = Customer::active()->whereNull('mac_reseller_id')->count();
        $collectionRate     = $totalClients > 0 ? round(($paidThis / $totalClients) * 100) : 0;
        $collectionRateLast = $totalClients > 0 ? round(($paidLast / $totalClients) * 100) : 0;

        return [
            'paid_clients'    => ['current' => $paidThis,        'last' => $paidLast],
            'unpaid_clients'  => ['current' => $unpaidThis,       'last' => $unpaidLast],
            'received_bill'   => ['current' => $receivedThis,     'last' => $receivedLast],
            'total_due'       => $totalDue,
            'generated_bill'  => ['current' => $generatedThis,    'last' => $generatedLast],
            'advance_amount'  => $advanceTotal,
            'monthly_bill'    => ['current' => $monthlyBillThis,  'last' => $monthlyBillLast],
            'collection_rate' => ['current' => $collectionRate,   'last' => $collectionRateLast],
        ];
    }
}