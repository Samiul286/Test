{{-- resources/views/layouts/app.blade.php --}}
{{-- ─────────────────────────────────────────────────────────────
     UNIFIED ADMIN / STAFF PORTAL LAYOUT
     UI/UX fully matched with the Client Self-Service Portal
     (resources/views/client/layout.blade.php):
       • Dark navy topbar (#1a1f36) + teal logo box (#00c897)
       • White fixed sidebar with teal left-accent active items
       • Rounded 12px cards / stat icons on pastel circles
       • Segoe UI typography on #f4f6f9 background
     Replaces the old AdminLTE-based chrome. Bootstrap 4 markup
     used inside page views is re-themed to the same palette, so
     every existing page keeps working with the new look.
     ───────────────────────────────────────────────────────────── --}}
<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    @php
        try { $companyName = \App\Models\Setting::get('company_name', 'SmartISP'); }
        catch (\Throwable $e) { $companyName = 'ISP Management'; }

        $saUser   = Auth::guard('super_admin')->user();
        $webUser  = Auth::user();
        $isSa     = $saUser && !$webUser;
        $topUser  = $webUser ?: $saUser;
        $homeUrl     = $isSa ? url('super-admin') : url('dashboard');
        $logoutRoute = $isSa ? 'super-admin.logout' : 'logout';
    @endphp

    <title>@yield('title', 'Dashboard') — {{ $companyName }}</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    {{-- ═══════════════ THEME CSS — always loaded ═══════════════ --}}
    <style>
        * { box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: #f4f6f9; color: #333;
            display: flex; flex-direction: column; min-height: 100vh;
            margin: 0;
        }
        a { color: #00c897; }
        h1, h2, h3, h4, h5, h6 { color: #1a1f36; }

        /* ═══════════════ Topbar (client portal) ═══════════════ */
        .topbar {
            background: #1a1f36; color: #fff; height: 56px;
            display: flex; align-items: center; justify-content: space-between;
            padding: 0 20px; position: fixed; top: 0; left: 0; right: 0; z-index: 200;
        }
        .topbar-brand {
            display: flex; align-items: center; gap: 10px;
            font-size: 18px; font-weight: 700; color: #fff; text-decoration: none;
        }
        .topbar-brand:hover { color: #fff; text-decoration: none; }
        .topbar-brand .logo-box {
            width: 36px; height: 36px; background: #00c897;
            border-radius: 8px; display: flex; align-items: center; justify-content: center;
            font-size: 16px; font-weight: 800; color: #fff;
        }
        .topbar-right { display: flex; align-items: center; gap: 12px; }
        .topbar-tools { display: flex; align-items: center; gap: 2px; list-style: none; margin: 0; padding: 0; }
        .topbar .lang-switch-btn, .topbar .notif-bell-btn { color: rgba(255,255,255,.8); }
        .topbar .lang-switch-btn:hover, .topbar .notif-bell-btn:hover { color: #fff; }
        .topbar .notif-badge { background: #e74c3c; }
        .user-pill {
            display: flex; align-items: center; gap: 8px;
            background: rgba(255,255,255,.1); border-radius: 999px;
            padding: 5px 14px 5px 5px; cursor: pointer;
        }
        .user-avatar {
            width: 30px; height: 30px; background: #00c897;
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            font-size: 12px; font-weight: 700; color: #fff;
        }
        .user-pill span { font-size: 13px; color: #fff; }
        .hamburger { background: none; border: none; color: #fff; font-size: 20px; cursor: pointer; display: none; }

        /* ── User Dropdown (client portal) ── */
        .user-dropdown {
            display: none !important; position: absolute;
            top: calc(100% + 10px); right: 0;
            background: #fff; border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,.15);
            min-width: 220px; z-index: 9999; overflow: hidden;
            border: 1px solid #eef0f5;
        }
        .user-dropdown.open { display: block !important; }
        .dropdown-header-ud {
            display: flex; align-items: center; gap: 12px; padding: 16px; background: #f8f9fc;
        }
        .dropdown-avatar {
            width: 42px; height: 42px; background: #1a1f36;
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            font-size: 16px; font-weight: 700; color: #00c897; flex-shrink: 0;
        }
        .dropdown-name { font-size: 14px; font-weight: 600; color: #1a1f36; }
        .dropdown-sub  { font-size: 12px; color: #888; margin-top: 2px; }
        .dropdown-divider-ud { height: 1px; background: #f0f2f7; }
        .ud-item {
            display: flex; align-items: center; gap: 10px;
            padding: 11px 16px; font-size: 13px; color: #444;
            text-decoration: none; transition: background .15s; background: none; border: none;
        }
        .ud-item i { width: 16px; text-align: center; color: #aaa; font-size: 14px; }
        .ud-item:hover { background: #f0faf7; color: #00c897; text-decoration: none; }
        .ud-item:hover i { color: #00c897; }

        /* ═══════════════ Sidebar (client portal) ═══════════════ */
        .main-wrapper { display: flex; margin-top: 56px; min-height: calc(100vh - 56px); }
        .sidebar {
            width: 240px; background: #fff; border-right: 1px solid #e8eaf0;
            position: fixed; top: 56px; left: 0; bottom: 0;
            overflow-y: auto; z-index: 100; transition: transform .25s;
        }
        .sidebar-nav { padding: 12px 0 24px; }
        .sidebar-label {
            font-size: 10px; font-weight: 700; letter-spacing: 1px;
            color: #9aa1b0; text-transform: uppercase;
            padding: 14px 20px 4px; margin-top: 4px;
        }
        .nav-item {
            display: flex; align-items: center; gap: 10px;
            padding: 10px 20px; font-size: 13.5px; color: #555;
            text-decoration: none; border-left: 3px solid transparent;
            transition: all .15s; white-space: nowrap;
        }
        .nav-item i:not([class*="text-"]) { width: 18px; text-align: center; font-size: 15px; color: #aaa; flex-shrink: 0; }
        .nav-item i { width: 18px; text-align: center; font-size: 15px; flex-shrink: 0; }
        .nav-item span { overflow: hidden; text-overflow: ellipsis; }
        .nav-item:hover { background: #f0faf7; color: #00c897; text-decoration: none; }
        .nav-item:hover i { color: #00c897; }
        .nav-item.active { background: #f0faf7; color: #00c897; border-left-color: #00c897; font-weight: 600; }
        .nav-item.active i:not([class*="text-"]) { color: #00c897; }
        .nav-item.active i { color: inherit; }
        .sidebar .nav-item i.text-success { color: #27ae60; }
        .sidebar .nav-item i.text-danger  { color: #e74c3c; }
        .sidebar .nav-item i.text-warning { color: #f39c12; }
        .sidebar .nav-item i.text-info    { color: #3a7bd5; }
        .sidebar .nav-item i.text-primary { color: #00c897; }
        .nav-toggle .nav-chevron {
            margin-left: auto; font-size: 11px; color: #aaa; width: auto;
            transition: transform .2s;
        }
        .nav-group.open > .nav-toggle .nav-chevron { transform: rotate(-90deg); color: #00c897; }
        .nav-sub { padding: 2px 0; }
        .nav-sub .nav-item { padding: 8px 20px 8px 44px; font-size: 12.5px; }
        .nav-sub .nav-item i { font-size: 13px; width: 16px; }
        .nav-divider { height: 1px; background: #f0f0f0; margin: 8px 0; }
        .sidebar-logout { border-top: 1px solid #f0f2f7; margin-top: 8px; padding-top: 8px; }

        /* ═══════════════ Page content ═══════════════ */
        .page-content { margin-left: 240px; padding: 24px; flex: 1; min-width: 0; }
        .page-head {
            display: flex; align-items: center; justify-content: space-between;
            gap: 12px; flex-wrap: wrap; margin-bottom: 20px;
        }
        .page-title { font-size: 22px; font-weight: 600; color: #1a1f36; margin: 0; }
        .page-actions { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
        .content-header { margin-bottom: 18px; }
        .content-header h1 { font-size: 22px; font-weight: 600; color: #1a1f36; margin: 0; }

        /* ── Alert (client portal) ── */
        .alert {
            padding: 14px 16px; border-radius: 8px; font-size: 13px;
            margin-bottom: 16px; display: flex; align-items: flex-start; gap: 10px;
        }
        .alert i { margin-top: 2px; }
        .alert-success { background: #f0fff8; border: 1px solid #b0e8d0; color: #1a7a50; border-left: 4px solid #00c897; }
        .alert-danger  { background: #fff0f0; border: 1px solid #ffd0d0; color: #c0392b; border-left: 4px solid #e74c3c; }
        .alert-warning { background: #fffbf0; border: 1px solid #ffe0a0; color: #b8860b; border-left: 4px solid #f39c12; }
        .alert-info    { background: #f0f6ff; border: 1px solid #c0d8ff; color: #2c5fa8; border-left: 4px solid #3a7bd5; }

        /* ═══════════════ Bootstrap 4 → client portal re-theme ═══════════════ */

        /* Buttons */
        .btn { border-radius: 8px; font-size: 13px; font-weight: 500; }
        .btn-sm, .btn-group-sm > .btn { border-radius: 7px; font-size: 12px; padding: 5px 12px; }
        .btn-lg, .btn-group-lg > .btn { border-radius: 10px; }
        .btn-primary { background: #00c897; border-color: #00c897; color: #fff; }
        .btn-primary:hover, .btn-primary:focus, .btn-primary:not(:disabled):not(.disabled):active,
        .btn-primary:not(:disabled):not(.disabled).active {
            background: #00b386; border-color: #00b386; color: #fff;
        }
        .btn-primary:focus, .btn-primary.focus { box-shadow: 0 0 0 .2rem rgba(0,200,151,.25); }
        .btn-info { background: #3a7bd5; border-color: #3a7bd5; color: #fff; }
        .btn-info:hover, .btn-info:focus, .btn-info:not(:disabled):not(.disabled):active {
            background: #2f68b8; border-color: #2f68b8; color: #fff;
        }
        .btn-success { background: #27ae60; border-color: #27ae60; color: #fff; }
        .btn-success:hover, .btn-success:not(:disabled):not(.disabled):active {
            background: #1f8b4c; border-color: #1f8b4c; color: #fff;
        }
        .btn-warning { background: #f39c12; border-color: #f39c12; color: #fff; }
        .btn-warning:hover, .btn-warning:not(:disabled):not(.disabled):active {
            background: #d68910; border-color: #d68910; color: #fff;
        }
        .btn-danger { background: #e74c3c; border-color: #e74c3c; color: #fff; }
        .btn-danger:hover, .btn-danger:not(:disabled):not(.disabled):active {
            background: #c0392b; border-color: #c0392b; color: #fff;
        }
        .btn-secondary { background: #95a5a6; border-color: #95a5a6; color: #fff; }
        .btn-secondary:hover, .btn-secondary:not(:disabled):not(.disabled):active {
            background: #7f8c8d; border-color: #7f8c8d; color: #fff;
        }
        .btn-dark { background: #1a1f36; border-color: #1a1f36; }
        .btn-outline-primary { color: #00c897; border-color: #00c897; }
        .btn-outline-primary:hover, .btn-outline-primary:not(:disabled):not(.disabled):active {
            background: #00c897; border-color: #00c897; color: #fff;
        }
        .btn-light { border-color: #e0e4ef; }

        /* Cards */
        .card {
            border-radius: 12px; border: 1px solid #eef0f5;
            box-shadow: none; margin-bottom: 20px;
        }
        .card > .card-header, .card-header {
            background: #fff; border-bottom: 1px solid #f0f2f7;
            padding: 14px 20px;
        }
        .card-header:first-child { border-radius: 12px 12px 0 0; }
        .card-header h3, .card-header .card-title, .card-title {
            font-size: 13px; font-weight: 600; color: #1a1f36;
            text-transform: uppercase; letter-spacing: .5px; margin: 0;
        }
        .card-header i, .card-title i { color: #00c897; }
        .card > .card-body { padding: 20px; }
        .card-footer { background: #fff; border-top: 1px solid #f0f2f7; border-radius: 0 0 12px 12px; }

        /* Tables */
        .table { color: #444; }
        .table thead th {
            background: #f8f9fc; color: #555; font-size: 12px; font-weight: 600;
            text-transform: uppercase; letter-spacing: .4px;
            padding: 10px 14px; border-bottom: 2px solid #eef0f5;
        }
        .table td, .table th { padding: 11px 14px; vertical-align: middle; border-color: #f4f6f9; }
        .table-hover tbody tr:hover { background-color: #fafbfd; }
        .table-striped tbody tr:nth-of-type(odd) { background-color: #fbfcfe; }
        .table-secondary, .table-secondary > td, .table-secondary > th { background-color: #f0f2f7; }

        /* Badges */
        .badge { border-radius: 999px; padding: 3px 10px; font-size: 11px; font-weight: 600; }
        .badge-primary, .badge-success { background: #00c897; color: #fff; }
        .badge-danger  { background: #e74c3c; color: #fff; }
        .badge-warning { background: #f39c12; color: #fff; }
        .badge-info    { background: #3a7bd5; color: #fff; }
        .badge-secondary { background: #95a5a6; color: #fff; }
        .badge-dark    { background: #1a1f36; color: #fff; }
        .badge-light   { background: #f0f2f7; color: #555; }

        /* Forms */
        .form-control {
            border: 1.5px solid #e0e4ef; border-radius: 8px;
            font-size: 13px; color: #333; height: auto;
        }
        .form-control:focus {
            border-color: #00c897; box-shadow: 0 0 0 .2rem rgba(0,200,151,.12);
        }
        .form-control.is-invalid { border-color: #e74c3c; }
        .form-control-sm, .input-group-sm > .form-control { border-radius: 7px; }
        .form-group label, .col-form-label { font-size: 12px; font-weight: 600; color: #555; }
        .invalid-feedback { font-size: 11px; color: #e74c3c; }
        .input-group-text {
            border: 1.5px solid #e0e4ef; border-radius: 8px; background: #f8f9fc; color: #555;
        }
        .custom-select { border: 1.5px solid #e0e4ef; border-radius: 8px; font-size: 13px; }
        .custom-control-input:checked ~ .custom-control-label::before {
            background-color: #00c897; border-color: #00c897;
        }
        .custom-control-input:checked ~ .custom-control-label::after { background-color: #fff; }

        /* Pagination */
        .pagination { margin-bottom: 0; }
        .page-link {
            border: 1px solid #e0e4ef; color: #555; font-size: 12.5px;
            margin-right: 4px; border-radius: 6px !important; padding: 5px 11px;
        }
        .page-link:hover { background: #f0faf7; color: #00c897; border-color: #bfeee1; }
        .page-item.active .page-link { background: #00c897; border-color: #00c897; color: #fff; }
        .page-item.disabled .page-link { background: #fff; color: #bbb; }

        /* Tabs */
        .nav-tabs { border-bottom: 1px solid #eef0f5; }
        .nav-tabs .nav-link {
            border: none; border-bottom: 2px solid transparent;
            color: #555; font-size: 13.5px; padding: 10px 16px;
        }
        .nav-tabs .nav-link:hover { color: #00c897; }
        .nav-tabs .nav-link.active {
            background: transparent; color: #00c897; font-weight: 600;
            border-bottom: 2px solid #00c897;
        }
        .nav-pills .nav-link { color: #555; border-radius: 8px; font-size: 13px; }
        .nav-pills .nav-link.active { background: #00c897; }

        /* Dropdown menus */
        .dropdown-menu {
            border-radius: 12px; border: 1px solid #eef0f5;
            box-shadow: 0 8px 30px rgba(0,0,0,.12); font-size: 13px;
        }
        .dropdown-item { color: #444; padding: 10px 16px; font-size: 13px; }
        .dropdown-item i { color: #aaa; width: 16px; text-align: center; }
        .dropdown-item:hover, .dropdown-item:focus {
            background: #f0faf7; color: #00c897; text-decoration: none;
        }
        .dropdown-item:hover i { color: #00c897; }
        .dropdown-divider { border-color: #f0f2f7; }

        /* Breadcrumb */
        .breadcrumb { background: transparent; margin: 0; padding: 0; font-size: 12px; }
        .breadcrumb-item a { color: #00c897; text-decoration: none; }
        .breadcrumb-item + .breadcrumb-item::before { color: #aaa; }
        .breadcrumb-item.active { color: #888; }

        /* Modal */
        .modal-content { border-radius: 12px; border: none; }
        .modal-header { border-bottom: 1px solid #f0f2f7; }
        .modal-header .modal-title { font-size: 16px; font-weight: 600; color: #1a1f36; }
        .modal-footer { border-top: 1px solid #f0f2f7; }

        /* Misc components */
        .list-group-item { border-color: #f0f2f7; font-size: 13px; }
        .progress { border-radius: 999px; background: #f0f2f7; }
        .progress-bar { background: #00c897; }
        .tooltip-inner, .popover { border-radius: 8px; }
        .text-primary { color: #00c897 !important; }
        .text-info { color: #3a7bd5 !important; }
        .text-success { color: #27ae60 !important; }
        .text-warning { color: #f39c12 !important; }
        .text-danger { color: #e74c3c !important; }
        .bg-primary { background-color: #00c897 !important; }
        .bg-info { background-color: #3a7bd5 !important; }
        .bg-success { background-color: #27ae60 !important; }
        .bg-warning { background-color: #f39c12 !important; }
        .bg-danger { background-color: #e74c3c !important; }
        .bg-dark { background-color: #1a1f36 !important; }
        .table-primary, .table-primary > td, .table-primary > th { background-color: #e0faf3; }
        .table-success, .table-success > td, .table-success > th { background-color: #e8fbe8; }
        .table-danger, .table-danger > td, .table-danger > th { background-color: #fff0f0; }
        .table-warning, .table-warning > td, .table-warning > th { background-color: #fffbf0; }
        .table-info, .table-info > td, .table-info > th { background-color: #eaf2fc; }

        /* ── AdminLTE legacy component shims (re-themed) ── */
        .info-box {
            background: #fff; border-radius: 12px; border: 1px solid #eef0f5;
            box-shadow: none; display: flex; align-items: stretch;
            min-height: 84px; margin-bottom: 16px; padding: 0; overflow: hidden;
        }
        .info-box-icon {
            width: 70px; min-width: 70px; display: flex; align-items: center; justify-content: center;
            font-size: 22px; background: #f0faf7; color: #00c897;
        }
        .info-box-content { flex: 1; padding: 12px 16px; display: flex; flex-direction: column; justify-content: center; }
        .info-box-text { font-size: 12px; color: #888; }
        .info-box-number { font-size: 22px; font-weight: 700; color: #1a1f36; }
        .info-box .progress { margin: 6px 0 0; }
        .info-box-more { font-size: 11px; color: #aaa; }

        .small-box { border-radius: 12px; padding: 16px 18px; margin-bottom: 16px; }
        .small-box h3 { font-size: 26px; font-weight: 700; }
        .small-box .icon { font-size: 60px; right: 12px; top: 4px; opacity: .25; }
        .small-box > .inner { padding: 0; }
        .small-box-footer { border-radius: 0 0 12px 12px; }

        .callout {
            border-radius: 12px; border: 1px solid #eef0f5; border-left: 4px solid #00c897;
            background: #fff; padding: 14px 16px; font-size: 13px;
        }
        .callout.callout-danger  { border-left-color: #e74c3c; background: #fff8f8; }
        .callout.callout-warning { border-left-color: #f39c12; background: #fffdf5; }
        .callout.callout-info    { border-left-color: #3a7bd5; background: #f7faff; }
        .callout.callout-success { border-left-color: #00c897; background: #f6fffc; }

        .overlay-wrapper, .card.overlay-wrapper { position: relative; }
        .overlay { border-radius: 12px; background: rgba(255,255,255,.85); }
        .overlay > i { color: #00c897; }

        /* ── DataTables harmony ── */
        .dataTables_wrapper { font-size: 13px; }
        .dataTables_wrapper .dataTables_filter input,
        .dataTables_wrapper .dataTables_length select {
            border: 1.5px solid #e0e4ef; border-radius: 8px; font-size: 13px;
            padding: 4px 10px; outline: none;
        }
        .dataTables_wrapper .dataTables_filter input:focus { border-color: #00c897; }
        .dataTables_wrapper .dataTables_info, .dataTables_wrapper .dataTables_paginate { font-size: 12.5px; color: #777; }
        .dataTables_wrapper .dataTables_empty { padding: 24px; text-align: center; color: #999; }

        /* Select2 → client portal look */
        .select2-container--default .select2-selection--single {
            border: 1.5px solid #e0e4ef; border-radius: 8px; height: 37px;
        }
        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 34px; padding-left: 12px; color: #333; font-size: 13px;
        }
        .select2-container--default .select2-selection--single .select2-selection__arrow { height: 35px; right: 6px; }
        .select2-container--default .select2-selection--multiple {
            border: 1.5px solid #e0e4ef; border-radius: 8px; font-size: 13px;
        }
        .select2-container--default.select2-container--focus .select2-selection--single,
        .select2-container--default.select2-container--focus .select2-selection--multiple {
            border-color: #00c897; box-shadow: 0 0 0 .2rem rgba(0,200,151,.12);
        }
        .select2-dropdown { border: 1.5px solid #e0e4ef; border-radius: 8px; font-size: 13px; }
        .select2-container--default .select2-results__option--highlighted[aria-selected] {
            background: #00c897; color: #fff;
        }
        .select2-container .select2-selection--single .select2-selection__rendered { padding-right: 28px; }
        .select2-search--dropdown .select2-search__field {
            border: 1.5px solid #e0e4ef; border-radius: 6px; outline: none;
        }
        .select2-search--dropdown .select2-search__field:focus { border-color: #00c897; }

        /* SweetAlert2 → client portal look */
        .swal2-popup { border-radius: 16px !important; font-family: 'Segoe UI', Tahoma, sans-serif !important; }
        .swal2-title { font-size: 1.1rem !important; padding: .5rem !important; margin-top: 20px; }
        .swal2-html-container { font-size: .9rem !important; margin: .3rem !important; }
        .swal2-confirm, .swal2-cancel, .swal2-deny { border-radius: 8px !important; }
        .swal-icon-sm { width: 30px !important; height: 30px !important; margin: .5rem auto !important; font-size: 1rem !important; }

        /* Toastr → softer */
        .toast { border-radius: 10px; }

        /* Compat badges kept from old layout */
        .badge-active    { background-color: #00c897; color: #fff; }
        .badge-inactive  { background-color: #95a5a6; color: #fff; }
        .badge-suspended { background-color: #f39c12; color: #fff; }
        .badge-expired   { background-color: #e74c3c; color: #fff; }

        /* ── Footer (client portal) ── */
        .footer {
            text-align: center; padding: 16px; font-size: 12px; color: #aaa;
            border-top: 1px solid #eef0f5; margin-top: auto; margin-left: 240px; background: #fff;
        }
        .footer a { color: #00c897; text-decoration: none; }

        /* ── Mobile (client portal) ── */
        @media (max-width: 768px) {
            .hamburger { display: block; }
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); box-shadow: 0 0 40px rgba(0,0,0,.2); }
            .page-content { margin-left: 0; padding: 16px; }
            .footer { margin-left: 0; }
            .user-pill span { display: none; }
        }

        /* ── RTL Support (Arabic) ── */
        @if(app()->getLocale() === 'ar')
        body { direction: rtl; text-align: right; }
        .sidebar { left: auto; right: 0; border-right: none; border-left: 1px solid #e8eaf0; }
        .page-content { margin-right: 240px !important; margin-left: 0 !important; }
        .footer { margin-right: 240px !important; margin-left: 0 !important; }
        .nav-item { border-left: none; border-right: 3px solid transparent; }
        .nav-item.active { border-right-color: #00c897; }
        .dropdown-menu-right, .lang-dropdown, .notif-dropdown, .user-dropdown { right: auto !important; left: 0 !important; }
        .ml-1, .ml-2, .ml-3 { margin-left: 0 !important; margin-right: .25rem !important; }
        .mr-1, .mr-2, .mr-3 { margin-right: 0 !important; margin-left: .25rem !important; }
        @endif
    </style>

    {{-- Optional plugin css (AdminLTE plugin-section compat) --}}
    @hasSection('plugins.Datatables')
        <link rel="stylesheet" href="{{ asset('vendor/datatables/css/dataTables.bootstrap4.min.css') }}">
    @endif

    @yield('extra_css')
    @stack('css')
</head>
<body>

{{-- ═══════════════ Topbar ═══════════════ --}}
<div class="topbar">
    <div style="display:flex; align-items:center; gap:12px;">
        <button class="hamburger" onclick="toggleSidebar()" type="button"><i class="fas fa-bars"></i></button>
        <a href="{{ $homeUrl }}" class="topbar-brand">
            <div class="logo-box">{{ strtoupper(mb_substr($companyName, 0, 1)) }}</div>
            <span>{{ $companyName }}</span>
        </a>
    </div>
    <div class="topbar-right">
        @if($webUser)
            <ul class="topbar-tools">
                <li>@include('partials.language-switcher')</li>
                <li>@include('partials.notification-bell')</li>
            </ul>
        @endif
        <div class="user-pill" id="userPill" onclick="toggleUserDropdown(event)" style="position:relative;">
            <div class="user-avatar">{{ strtoupper(mb_substr($topUser->name ?? $topUser->email ?? 'U', 0, 2)) }}</div>
            <span>{{ $topUser->name ?? $topUser->email ?? 'User' }}</span>
            <i class="fas fa-chevron-down" style="font-size:10px; color:#aaa; margin-left:4px;"></i>

            <div class="user-dropdown" id="userDropdown" onclick="event.stopPropagation()">
                <div class="dropdown-header-ud">
                    <div class="dropdown-avatar">{{ strtoupper(mb_substr($topUser->name ?? $topUser->email ?? 'U', 0, 2)) }}</div>
                    <div>
                        <div class="dropdown-name">{{ $topUser->name ?? 'Super Admin' }}</div>
                        <div class="dropdown-sub">{{ $topUser->email ?? 'Welcome !' }}</div>
                    </div>
                </div>
                <div class="dropdown-divider-ud"></div>
                @if($webUser)
                    <a href="{{ route('profile.edit') }}" class="ud-item">
                        <i class="fas fa-user"></i> My Profile
                    </a>
                    <div class="dropdown-divider-ud"></div>
                @endif
                <form method="POST" action="{{ route($logoutRoute) }}">
                    @csrf
                    <button type="submit" class="ud-item" style="width:100%; text-align:left; color:#e74c3c;">
                        <i class="fas fa-sign-out-alt" style="color:#e74c3c;"></i> Logout
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

{{-- ═══════════════ Sidebar ═══════════════ --}}
<div class="sidebar" id="sidebar">
    <nav class="sidebar-nav">
        @php
            try { $menuItems = \App\Support\AdminMenu::items(); }
            catch (\Throwable $e) { $menuItems = []; }
        @endphp
        @include('partials.admin-sidebar', ['items' => $menuItems])

        <div class="sidebar-logout">
            <form method="POST" action="{{ route($logoutRoute) }}">
                @csrf
                <button type="submit" class="nav-item" style="width:100%; background:none; border:none; cursor:pointer; text-align:left;">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </button>
            </form>
        </div>
    </nav>
</div>

{{-- ═══════════════ Main Content ═══════════════ --}}
<div class="main-wrapper">
    <div class="page-content">

        {{-- Page header: page_title (app convention) → content_title → content_header (AdminLTE convention) --}}
        @hasSection('page_title')
            <div class="page-head">
                <h1 class="page-title">@yield('page_title')</h1>
                @hasSection('page_actions')
                    <div class="page-actions">@yield('page_actions')</div>
                @endif
            </div>
        @else
            @hasSection('content_title')
                <div class="page-head">
                    <h1 class="page-title">@yield('content_title')</h1>
                    @hasSection('page_actions')
                        <div class="page-actions">@yield('page_actions')</div>
                    @endif
                </div>
            @else
                @hasSection('content_header')
                    <div class="content-header">@yield('content_header')</div>
                @endif
            @endif
        @endif

        {{-- Session alerts — client portal style --}}
        @if(session('success'))
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span>{{ session('success') }}</span>
            </div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <span>{{ session('error') }}</span>
            </div>
        @endif
        @if(session('warning'))
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i>
                <span>{{ session('warning') }}</span>
            </div>
        @endif

        {{-- Shared modal (Income / Expense quick category) --}}
        @include('accounting._quick_add_category_modal')

        {{-- Page body: page_content (app convention) / content (AdminLTE convention) --}}
        @hasSection('page_content')
            @yield('page_content')
        @endif
        @hasSection('content')
            @yield('content')
        @endif

    </div>
</div>

{{-- ═══════════════ Footer ═══════════════ --}}
<div class="footer">
    {{ date('Y') }} &copy; {{ $companyName }}
</div>

{{-- ═══════════════ CORE SCRIPTS — always loaded ═══════════════ --}}
<script src="{{ asset('vendor/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

{{-- Optional plugin js (AdminLTE plugin-section compat) --}}
@hasSection('plugins.Datatables')
    <script src="{{ asset('vendor/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('vendor/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
@endif
@hasSection('plugins.Chartjs')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
@endif

{{-- @section('js') kept for @parent compat: legacy child views append here --}}
@section('js')
    {{-- layout-level js lives above; children may @parent-append below --}}
@show

<script>
    // ── Sidebar toggle (mobile) ─────────────────────────────
    function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('open');
    }

    // ── User dropdown (client portal behaviour) ────────────
    function toggleUserDropdown(e) {
        e.stopPropagation();
        document.getElementById('userDropdown').classList.toggle('open');
    }
    document.addEventListener('click', function() {
        var dd = document.getElementById('userDropdown');
        if (dd) dd.classList.remove('open');
    });

    // ── AdminLTE data-widget shim (collapse / remove) ──────
    document.addEventListener('click', function(e) {
        var btn = e.target.closest('[data-widget]');
        if (!btn) return;
        var w = btn.getAttribute('data-widget');
        var card = btn.closest('.card');
        if (!card) return;
        if (w === 'collapse') {
            var body = card.querySelector('.card-body');
            if (body) body.style.display = (body.style.display === 'none') ? '' : 'none';
        } else if (w === 'remove') {
            card.remove();
        }
    });

    // ── Global SweetAlert Delete Confirm (kept from old layout) ──
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.swal-delete').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var form = this.closest('form');
                var msg  = this.getAttribute('data-message') || 'Are you sure?';
                Swal.fire({
                    title: 'Are you sure?',
                    text: msg,
                    showCancelButton: true,
                    confirmButtonColor: '#e74c3c',
                    cancelButtonColor: '#95a5a6',
                    confirmButtonText: 'Yes, Delete',
                    cancelButtonText: 'Cancel',
                    width: '350px'
                }).then(function(result) {
                    if (result.isConfirmed) form.submit();
                });
            });
        });
    });
</script>

@yield('extra_js')
@stack('js')
</body>
</html>
