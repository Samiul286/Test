{{-- resources/views/layouts/auth.blade.php --}}
{{-- Auth shell for Staff / Admin / Super Admin login & password flows.
     Design identical to the Client Self-Service Portal login page:
     navy gradient background + white rounded card + teal brand box. --}}
<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Login') — @yield('brand_name', 'ISP Management')</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: linear-gradient(135deg, #1a1f36 0%, #2d3561 100%);
            min-height: 100vh;
            display: flex; align-items: center; justify-content: center;
        }
        .login-wrapper { width: 100%; max-width: 400px; padding: 1rem; }
        .login-card {
            background: #fff; border-radius: 16px;
            padding: 2.5rem 2rem; box-shadow: 0 20px 60px rgba(0,0,0,.3);
        }
        .brand { text-align: center; margin-bottom: 2rem; }
        .brand-logo {
            width: 60px; height: 60px; background: #00c897;
            border-radius: 14px; display: flex; align-items: center; justify-content: center;
            margin: 0 auto 12px; font-size: 26px; font-weight: 800; color: #fff;
        }
        .brand h1 { font-size: 20px; font-weight: 700; color: #1a1f36; }
        .brand p  { font-size: 13px; color: #888; margin-top: 4px; }

        .form-group { margin-bottom: 14px; }
        .form-group label { display: block; font-size: 12px; font-weight: 600; color: #555; margin-bottom: 5px; text-transform: uppercase; letter-spacing: .4px; }
        .input-wrap { position: relative; }
        .input-wrap i { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #bbb; font-size: 14px; }
        .form-control {
            width: 100%; padding: 10px 12px 10px 38px;
            border: 1.5px solid #e0e4ef; border-radius: 8px;
            font-size: 13px; color: #333; outline: none; transition: border-color .2s;
        }
        .form-control:focus { border-color: #00c897; }
        .form-control.is-invalid { border-color: #e74c3c; }
        .invalid-feedback { font-size: 11px; color: #e74c3c; margin-top: 4px; }

        .remember-row { display: flex; align-items: center; gap: 8px; margin-bottom: 1.25rem; font-size: 13px; color: #666; }

        .btn-login {
            width: 100%; padding: 12px;
            background: #00c897; color: #fff; border: none;
            border-radius: 8px; font-size: 15px; font-weight: 600;
            cursor: pointer; transition: background .2s;
        }
        .btn-login:hover { background: #00b386; }

        .btn-outline-soft {
            width: 100%; padding: 11px; background: #fff; color: #555;
            border: 1.5px solid #e0e4ef; border-radius: 8px;
            font-size: 13px; font-weight: 600; cursor: pointer;
            text-decoration: none; display: inline-block; text-align: center;
            transition: all .2s;
        }
        .btn-outline-soft:hover { border-color: #00c897; color: #00c897; text-decoration: none; }

        .alert { padding: 10px 14px; border-radius: 8px; font-size: 13px; margin-bottom: 1rem; display: flex; align-items: flex-start; gap: 8px; }
        .alert-danger  { background: #fff0f0; color: #c0392b; border: 1px solid #ffd0d0; }
        .alert-success { background: #f0fff8; color: #1a7a50; border: 1px solid #b0e8d0; }

        .auth-links { margin-top: 1.25rem; text-align: center; font-size: 13px; color: #888; }
        .auth-links a { color: #00c897; text-decoration: none; font-weight: 600; }
        .auth-links a:hover { text-decoration: underline; }

        .hint-box {
            margin-top: 1.5rem; background: #f0faf7;
            border: 1px solid #b0e8d0; border-radius: 8px;
            padding: 12px 14px; font-size: 12px; color: #1a7a50;
        }
        .hint-box strong { display: block; margin-bottom: 4px; }

        @if(app()->getLocale() === 'ar')
        body { direction: rtl; text-align: right; }
        .input-wrap i { left: auto; right: 12px; }
        .form-control { padding: 10px 38px 10px 12px; }
        @endif
    </style>
    @yield('extra_css')
</head>
<body>
<div class="login-wrapper">
    <div class="login-card">
        <div class="brand">
            @php
                try { $brand = \App\Models\Setting::get('company_name', 'SmartISP'); }
                catch (\Throwable $e) { $brand = 'ISP Management'; }
            @endphp
            <div class="brand-logo">{{ strtoupper(mb_substr($brand, 0, 1)) }}</div>
            <h1>{{ $brand }}</h1>
            <p>@yield('auth_subtitle', 'ISP Management — Admin & Staff Portal')</p>
        </div>

        @hasSection('auth_content')
            @yield('auth_content')
        @endif
    </div>
</div>
@yield('extra_js')
</body>
</html>
