{{-- resources/views/layouts/super-admin.blade.php --}}
{{-- Thin wrapper — UI/UX comes from the unified layouts.app
     (client-portal design). layouts.app is guard-aware and renders
     the Super Admin user + logout automatically when browsing on
     the 'super_admin' guard. --}}
@extends('layouts.app')

@section('title', 'Super Admin — ' . config('adminlte.title'))
