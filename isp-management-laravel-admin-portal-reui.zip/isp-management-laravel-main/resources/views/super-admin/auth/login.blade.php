{{-- resources/views/super-admin/auth/login.blade.php --}}
{{-- Super Admin login — client-portal-matched design --}}
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="utf-8">
    <title>Super Admin Login — ISP Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: linear-gradient(135deg, #1a1f36 0%, #2d3561 100%);
            min-height: 100vh;
            display: flex; align-items: center; justify-content: center;
        }
        .login-wrapper { width: 100%; max-width: 400px; padding: 1rem; }
        .login-card {
            background: #fff; border-radius: 16px;
            padding: 2.5rem 2rem; box-shadow: 0 20px 60px rgba(0,0,0,.3);
        }
        .brand { text-align: center; margin-bottom: 2rem; }
        .brand-logo {
            width: 60px; height: 60px; background: #1a1f36;
            border-radius: 14px; display: flex; align-items: center; justify-content: center;
            margin: 0 auto 12px; font-size: 24px; font-weight: 800; color: #00c897;
        }
        .brand h1 { font-size: 20px; font-weight: 700; color: #1a1f36; }
        .brand p  { font-size: 13px; color: #888; margin-top: 4px; }

        .form-group { margin-bottom: 14px; }
        .form-group label { display: block; font-size: 12px; font-weight: 600; color: #555; margin-bottom: 5px; text-transform: uppercase; letter-spacing: .4px; }
        .input-wrap { position: relative; }
        .input-wrap i { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #bbb; font-size: 14px; }
        .form-control {
            width: 100%; padding: 10px 12px 10px 38px;
            border: 1.5px solid #e0e4ef; border-radius: 8px;
            font-size: 13px; color: #333; outline: none; transition: border-color .2s;
        }
        .form-control:focus { border-color: #00c897; }

        .remember-row { display: flex; align-items: center; gap: 8px; margin-bottom: 1.25rem; font-size: 13px; color: #666; }

        .btn-login {
            width: 100%; padding: 12px;
            background: #00c897; color: #fff; border: none;
            border-radius: 8px; font-size: 15px; font-weight: 600;
            cursor: pointer; transition: background .2s;
        }
        .btn-login:hover { background: #00b386; }

        .alert { padding: 10px 14px; border-radius: 8px; font-size: 13px; margin-bottom: 1rem; }
        .alert-danger  { background: #fff0f0; color: #c0392b; border: 1px solid #ffd0d0; }
    </style>
</head>
<body>

<div class="login-wrapper">
    <div class="login-card">
        <div class="brand">
            <div class="brand-logo"><i class="fas fa-user-shield"></i></div>
            <h1>Super Admin</h1>
            <p>ISP Management — Central Panel</p>
        </div>

        @if($errors->any())
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i>
            <div>
                @foreach($errors->all() as $error)
                    {{ $error }}<br>
                @endforeach
            </div>
        </div>
        @endif

        <form action="{{ route('super-admin.login.post') }}" method="POST">
            @csrf
            <div class="form-group">
                <label>Email</label>
                <div class="input-wrap">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="email" class="form-control"
                           placeholder="admin@example.com"
                           value="{{ old('email') }}" required autofocus>
                </div>
            </div>
            <div class="form-group">
                <label>Password</label>
                <div class="input-wrap">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" class="form-control"
                           placeholder="Your password" required>
                </div>
            </div>
            <div class="remember-row">
                <input type="checkbox" name="remember" id="remember" value="1">
                <label for="remember" style="margin:0; text-transform:none; letter-spacing:0; font-size:13px; font-weight:500;">আমাকে মনে রাখো</label>
            </div>
            <button type="submit" class="btn-login">
                <i class="fas fa-sign-in-alt" style="margin-right:6px;"></i> লগইন করুন
            </button>
        </form>
    </div>
</div>

</body>
</html>
