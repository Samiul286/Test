{{-- resources/views/partials/admin-sidebar.blade.php --}}
{{-- Client-portal-styled sidebar renderer.
     Expects: $items (processed by \App\Support\AdminMenu::items()).
     Recursive include handles nested submenus. --}}
@foreach ($items as $i => $item)
    @if ($item['type'] === 'header')
        <div class="sidebar-label">{{ $item['text'] }}</div>
    @elseif ($item['type'] === 'item')
        <a href="{{ $item['href'] }}"
           class="nav-item {{ !empty($item['active']) ? 'active' : '' }}"
           @if(!empty($item['active'])) aria-current="page" @endif>
            <i class="{{ $item['icon'] ?? 'far fa-circle' }}"
               @if(!empty($item['icon_color'])) style="color: {{ $item['icon_color'] }}" @endif></i>
            <span>{{ $item['text'] }}</span>
        </a>
    @elseif ($item['type'] === 'submenu')
        @php $groupId = 'menu-' . md5($item['text']); @endphp
        <div class="nav-group {{ !empty($item['active']) ? 'open' : '' }}">
            <a href="#{{ $groupId }}" data-toggle="collapse" role="button"
               aria-expanded="{{ !empty($item['active']) ? 'true' : 'false' }}"
               aria-controls="{{ $groupId }}"
               class="nav-item nav-toggle {{ !empty($item['active']) ? 'active' : '' }}">
                <i class="{{ $item['icon'] ?? 'far fa-clone' }}"
                   @if(!empty($item['icon_color'])) style="color: {{ $item['icon_color'] }}" @endif></i>
                <span>{{ $item['text'] }}</span>
                <i class="fas fa-angle-left nav-chevron"></i>
            </a>
            <div class="collapse {{ !empty($item['active']) ? 'show' : '' }}" id="{{ $groupId }}">
                <div class="nav-sub">
                    @include('partials.admin-sidebar', ['items' => $item['children']])
                </div>
            </div>
        </div>
    @endif
@endforeach
