{{-- resources/views/auth/register.blade.php --}}
{{-- Staff registration — client-portal-matched design --}}
@extends('layouts.auth')

@section('title', 'Register')

@section('auth_content')
    @if($errors->any())
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i>
            <div>
                @foreach($errors->all() as $err)
                    {{ $err }}<br>
                @endforeach
            </div>
        </div>
    @endif

    <form method="POST" action="{{ route('register') }}">
        @csrf

        <div class="form-group">
            <label>Name</label>
            <div class="input-wrap">
                <i class="fas fa-user"></i>
                <input type="text" name="name"
                    class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}"
                    placeholder="Full name"
                    value="{{ old('name') }}" required autofocus>
            </div>
            @error('name')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label>Email Address</label>
            <div class="input-wrap">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email"
                    class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                    placeholder="you@company.com"
                    value="{{ old('email') }}" required>
            </div>
            @error('email')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label>Password</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" name="password"
                    class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                    placeholder="Password" autocomplete="new-password" required>
            </div>
            @error('password')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label>Confirm Password</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" name="password_confirmation"
                    class="form-control" placeholder="Confirm password" autocomplete="new-password" required>
            </div>
        </div>

        <button type="submit" class="btn-login">
            <i class="fas fa-user-plus" style="margin-right:6px;"></i> Register
        </button>
    </form>

    <div class="auth-links">
        Already have an account?
        <a href="{{ route('login') }}">Login</a>
    </div>
@endsection
