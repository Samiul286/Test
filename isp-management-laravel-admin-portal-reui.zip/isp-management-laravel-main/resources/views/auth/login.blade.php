{{-- resources/views/auth/login.blade.php --}}
{{-- Staff / Admin login — client-portal-matched design --}}
@extends('layouts.auth')

@section('title', 'Login')

@section('auth_content')
    @if($errors->any())
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i>
            <div>
                @foreach($errors->all() as $err)
                    {{ $err }}<br>
                @endforeach
            </div>
        </div>
    @endif
    @if(session('status'))
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> {{ session('status') }}
        </div>
    @endif

    <form method="POST" action="{{ route('login') }}">
        @csrf

        <div class="form-group">
            <label>Email Address</label>
            <div class="input-wrap">
                <i class="fas fa-user"></i>
                <input type="email" name="email"
                    class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                    placeholder="you@company.com"
                    value="{{ old('email') }}"
                    autocomplete="username" required autofocus>
            </div>
            @error('email')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label>Password</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" name="password"
                    class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                    placeholder="Your password"
                    autocomplete="current-password" required>
            </div>
            @error('password')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="remember-row">
            <input type="checkbox" name="remember" id="remember" value="1" {{ old('remember') ? 'checked' : '' }}>
            <label for="remember" style="margin:0; text-transform:none; letter-spacing:0; font-size:13px; font-weight:500;">Remember me</label>
        </div>

        <button type="submit" class="btn-login">
            <i class="fas fa-sign-in-alt" style="margin-right:6px;"></i> Login
        </button>
    </form>

    <div class="auth-links">
        <a href="{{ route('password.request') }}">Forgot your password?</a>
    </div>

    <div class="hint-box">
        <strong><i class="fas fa-info-circle"></i> Staff Login</strong>
        Use the email &amp; password provided by your ISP administrator.
    </div>
@endsection
