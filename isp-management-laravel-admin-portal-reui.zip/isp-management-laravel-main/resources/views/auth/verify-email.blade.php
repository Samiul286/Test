{{-- resources/views/auth/verify-email.blade.php --}}
@extends('layouts.auth')

@section('title', 'Verify Email')

@section('auth_content')
    @if(session('status') == 'verification-link-sent')
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i>
            {{ __('A new verification link has been sent to the email address you provided during registration.') }}
        </div>
    @endif

    <p style="font-size:13px; color:#666; margin-bottom:1.25rem;">
        {{ __('Thanks for signing up! Before getting started, could you verify your email address by clicking on the link we just emailed to you? If you didn\'t receive the email, we will gladly send you another.') }}
    </p>

    <div style="display:flex; flex-direction:column; gap:10px;">
        <form method="POST" action="{{ route('verification.send') }}">
            @csrf
            <button type="submit" class="btn-login" style="font-size:14px;">
                <i class="fas fa-envelope-open-text" style="margin-right:6px;"></i> Resend Verification Email
            </button>
        </form>

        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <a href="{{ route('logout') }}" onclick="event.preventDefault(); this.closest('form').submit();"
               class="btn-outline-soft">
                <i class="fas fa-sign-out-alt" style="margin-right:6px;"></i> Log Out
            </a>
        </form>
    </div>
@endsection
