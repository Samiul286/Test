{{-- resources/views/auth/passwords/email.blade.php --}}
{{-- Legacy alias — now rendered with the unified auth design --}}
@extends('layouts.auth')

@section('title', 'Forgot Password')

@section('auth_content')
    @if($errors->any())
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i>
            <div>
                @foreach($errors->all() as $err)
                    {{ $err }}<br>
                @endforeach
            </div>
        </div>
    @endif
    @if(session('status'))
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> {{ session('status') }}
        </div>
    @endif

    <p style="font-size:13px; color:#666; margin-bottom:1.25rem;">
        {{ __('Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one.') }}
    </p>

    <form method="POST" action="{{ route('password.email') }}">
        @csrf

        <div class="form-group">
            <label>Email Address</label>
            <div class="input-wrap">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email"
                    class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                    placeholder="you@company.com"
                    value="{{ old('email') }}" required autofocus>
            </div>
            @error('email')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <button type="submit" class="btn-login">
            <i class="fas fa-paper-plane" style="margin-right:6px;"></i> Email Password Reset Link
        </button>
    </form>

    <div class="auth-links">
        Remembered it?
        <a href="{{ route('login') }}">Back to Login</a>
    </div>
@endsection
