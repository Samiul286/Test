{{-- resources/views/auth/passwords/confirm.blade.php --}}
{{-- Legacy alias — now rendered with the unified auth design --}}
@extends('layouts.auth')

@section('title', 'Confirm Password')

@section('auth_content')
    @if($errors->any())
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i>
            <div>
                @foreach($errors->all() as $err)
                    {{ $err }}<br>
                @endforeach
            </div>
        </div>
    @endif

    <p style="font-size:13px; color:#666; margin-bottom:1.25rem;">
        {{ __('This is a secure area of the application. Please confirm your password before continuing.') }}
    </p>

    <form method="POST" action="{{ route('password.confirm') }}">
        @csrf

        <div class="form-group">
            <label>Password</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" name="password"
                    class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                    placeholder="Your password" autocomplete="current-password" required>
            </div>
            @error('password')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <button type="submit" class="btn-login">
            <i class="fas fa-shield-alt" style="margin-right:6px;"></i> Confirm
        </button>
    </form>
@endsection
